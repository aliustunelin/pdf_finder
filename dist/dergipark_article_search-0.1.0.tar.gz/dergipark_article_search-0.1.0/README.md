# pdf_finder
PDF Finder to Article Research Web Sites powered by Python


<br>
<br>
<br>

This is research from Dergipark now, <br>
This script find's any search topic then download from Article web site then save to be pdf
<br>
Basic python run command is running the code
<br>
```
python .\main.py
```
<br>


